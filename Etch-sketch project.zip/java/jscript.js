const divScreen = document.querySelector('#inline-screen');
const btnearase = document.querySelector('#earase-butt');
const btnColor = document.querySelector('#change-colors');


createGrid(16);


function createGrid(number) {
  divScreen.setAttribute('style', 'grid-template: repeat('+ number + ', 1fr)' + ' \/ ' + 'repeat(' + number + ', 1fr)');

  for(let i = 0; i < number * number; i++) {
    const divBox = document.createElement('div');

    divBox.setAttribute('class', 'box');

    divScreen.appendChild(divBox);
  }
}

function random(number) { 
  return Math.floor(Math.random() * number );
}

divScreen.addEventListener('mouseover', function(event)  { 
  const randomColor = 'rgb(' + random(255) + ',' + random(255) + ',' + random(255) + ')';
  const currentBox = event.target;


  if(currentBox.id ==='inline-screen') { 
    return;

  } else {
    if(divScreen.className === 'colorful') {
      currentBox.style.backgroundColor = randomColor;
      
    } else {
      fadeEffect(currentBox);
    }
  }
});

function fadeEffect(element) {
  const currentWhiteLevel = element.getAttribute('style', 'background-color');
  
  if(currentWhiteLevel === null) {
    element.setAttribute('style', 'background-color: hsl(0, 0%, 70%)');
    
  
  } else {
    let colorMode = currentWhiteLevel.substr(18, 3);
    let whiteLevelModifier = currentWhiteLevel.substr(29, 1);
    
    
    if(colorMode === 'rgb') {
      element.setAttribute('style', 'background-color: hsl(0, 0%, 70%)');
     
    } else if(whiteLevelModifier <= 7 && whiteLevelModifier >= 0) {
       whiteLevelModifier--;
       element.setAttribute('style', 'background-color: hsl(0, 0%, ' + whiteLevelModifier + '0%)');
    }
  }
}

btnColor.addEventListener('click', function()  {
  divScreen.classList.toggle('colorful');
  toggleAnimation();
});


btnearase.addEventListener('click', function() {
  event.stopPropagation(); 
  promptUser();
});

function promptUser() {
  let gridSize = prompt('Give me a number up to 256 and I\'ll magically produce a number X number grid for you to draw on!', 16);

  if(gridSize === null) { 
    return;
  }

 
  isNaN(gridSize) ? promptUser() : checkInput(gridSize);
}

function checkInput(number) {
  if(number <= 0 || number % 1 !== 0 || number > 256) {
    promptUser();

  } else {
    resetBoard();
    createGrid(number);
  }
}

function resetBoard() {
  const colorBoxes = document.querySelectorAll('.box');

  colorBoxes.forEach((div) => {
    div.parentNode.removeChild(div);
  });
}